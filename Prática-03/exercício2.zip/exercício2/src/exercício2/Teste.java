
package exercício2;


public class Teste {
    public static void main(String[] args) {
        Analista p1 = new Analista("José", "001", new Data(1,1,2017));
        System.out.println(p1);
    }
}