/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício2;

/**
 *
 * @author Aluno
 */
public class Analista {
    private String nome;
    private String matrícula;
    private String nível;
    private  double adicional;
    private  double salário;
    private Data dataAdmissao;

    
    public Analista(String nome, String matrícula, Data dataAdmissao) {
        this.nome = nome;
        this.matrícula = matrícula;
        this.nível = "júnior";
        this.adicional = 0;
        this.salário = 1500;
        this.dataAdmissao = dataAdmissao;
    }
    public String getNome(){
        return nome;
    }
    public String getMatrícula(){
        return matrícula;
    }
    public String getNível(){
        return nível;
    }
    public double getSalário(){
        return salário;
    }
    public double getAdicional(){
        return adicional;
    }
    public double getSalárioTotal(){
            return salário + adicional;
    }
      public void setNível(String nível){
          this.nível = nível;
             switch (nível){
                case "júnior" :
                    this.salário = 1500;// + adicional;
                    break;
                case "pleno" :
                    this.salário = 3000;// + adicional;
                    break;
                case "sênior" :
                    this.salário = 5000;// + adicional;
                    break;
            }
   }
    public void setSalário(double salário){
      this.salário = salário;
   }
     public void setAdicional(double adicional){
      this.adicional = adicional; 
  }

    public String toString() {
        String anl = "Nome: " +nome;
        anl += "\nMatrícula: " + matrícula; 
        anl += "\nNível: " + nível;
        anl += "\nSalário: " + getSalárioTotal();
        anl += "\nData admissão: " + dataAdmissao;
        return anl;
    }

    
}
