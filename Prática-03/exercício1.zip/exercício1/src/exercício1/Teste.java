
package exercício1;


public class Teste {
    public static void main(String[] args) {
        Analista p1 = new Analista("José", "001");
        p1.setAdicional(500);
        System.out.println(p1);
        Analista p2 = new Analista("João", "002");
        p2.setAdicional(300);
        System.out.println(p2);
        Analista p3 = new Analista("Maria", "003");
        p3.setAdicional(800);
        System.out.println(p3);
        p2.setNível("pleno");
        p3.setNível("pleno");
        p1 = p3;
        System.out.println(p1);
        p1.setNível("sênior");
        System.out.println(p1);
        System.out.println(p3);
    }
}
/*p1 e p3 tem os mesmos atributos pois p1 passou
a "apontar" para o mesmo objeto de p3 */
 