
package exercicio3;

    public class Volume {

private int id;
private int altura;
private boolean stereo;
private static int ultId = 1;
public Volume(int altura, boolean stereo){

this.altura = altura;
this.stereo = stereo;
id = ultId;
ultId++;
}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public boolean isStereo() {
        return stereo;
    }

    public void setStereo(boolean stereo) {
        this.stereo = stereo;
    }

    public static int getUltId() {
        return ultId;
    }

    public static void setUltId(int ultId) {
        Volume.ultId = ultId;
    }

    @Override
    public String toString() {
        return "Volume{" + "id=" + id + ", altura=" + altura + '}';
    }



}
