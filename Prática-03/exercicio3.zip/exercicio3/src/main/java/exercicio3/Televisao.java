
package exercicio3;

public class Televisao {
private int id;
private int canal;
private Volume volume;
private static int ultId = 1;

public Televisao(int c, Volume vol){

canal = c;
volume = vol;
id = ultId;
ultId++;

}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCanal() {
        return canal;
    }

    public void setCanal(int canal) {
        this.canal = canal;
    }

    public Volume getVolume() {
        return volume;
    }

    public void setVolume(Volume volume) {
        this.volume = volume;
    }

    public static int getUltId() {
        return ultId;
    }

    public static void setUltId(int ultId) {
        Televisao.ultId = ultId;
    }

    @Override
    public String toString() {
        return "Televisao{" + "id=" + id + ", canal=" + canal + ", volume=" + volume + '}';
    }

}
