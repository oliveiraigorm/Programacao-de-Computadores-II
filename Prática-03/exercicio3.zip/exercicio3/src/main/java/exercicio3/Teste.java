
package exercicio3;

public class Teste {
 public static void alteraVolume(Volume vol){
vol.setVolume();
}

public static void main(String[] args){

Volume vol1 = new Volume(20,true);
Volume vol2 = new Volume(15,true);
Televisao tv1 = new Televisao(22,vol1);
Televisao tv2 = new Televisao(10,vol2);
//vol1 = vol2;
alteraVolume(vol1);
System.out.println(tv1);
System.out.println(tv2);

}
}
