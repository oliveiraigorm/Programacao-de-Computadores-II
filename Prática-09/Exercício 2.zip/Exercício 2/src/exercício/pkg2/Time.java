/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg2;

/**
 *
 * @author Aluno
 */
public class Time implements Comparable {

    private String nome;
    private double pontos;

    public Time(String nome, double pontos) {
        this.nome = nome;
        this.pontos = pontos;
    }

    
    public double getPontos() {
        return pontos;
    }

    public void setPontos(double pontos) {
        this.pontos = pontos;
    }

    public double compareTo(Time t) {
        if (t.getPontos() < this.pontos) {
            return -1;
        }
        if (t.getPontos() > this.pontos) {
            return 1;
        }
        return 0;        
    }

    @Override
    public String toString() {
        return "\nNome: " + nome + " pontos:" + pontos;
    }

    @Override
    public double compareTo(Object t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
