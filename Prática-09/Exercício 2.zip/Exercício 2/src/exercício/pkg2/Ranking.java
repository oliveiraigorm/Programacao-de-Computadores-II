/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Aluno
 */
public class Ranking {
    Time []at = new Time[10]; 

    public void adicionarTimes(Time x){
        int i;
        for(i=0;i<10;i++){
            if(at[i]==null){
                at[i]=x;
                break;
            }
            if(i==9)
                System.out.println("Ranking Cheio!");
    }
    }

    @Override
    public String toString() {
        String s = "";
        for(int i=0;i<10;i++){
            if(at[i]!=null)
            s+=at[i].toString();
        }
        return "Ranking:\n\t"+s;
    }
    
    public Time[] getTimes(){
        Arrays.sort(at);
        return at;
    }
}
