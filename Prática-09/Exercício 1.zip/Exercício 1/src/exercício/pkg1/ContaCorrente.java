/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg1;

public class ContaCorrente extends Conta {

    private double limite;

    public ContaCorrente(double agencia, double número, double saldo, double limite) {
        super(agencia, número, saldo);
        this.limite = limite;
    }

    public void setLimite(double l) {
        if (l > 0) {
            limite = l;
        }

    }

    public double getLimite() {
        return limite;
    }

    @Override
    public double getSaldoTotal() {
        return saldo+limite;
    }

    @Override
    public String toString() {
        return "ContaCorrente{" +super.toString()+ " limite: " + limite + '}';
    }
    

}
