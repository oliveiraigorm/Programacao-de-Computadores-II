package exercício.pkg1;

public abstract class Conta {

    double agencia, número, saldo;

    public Conta(double agencia, double número, double saldo) {
        this.agencia = agencia;
        this.número = número;
        this.saldo = saldo;
    }

    public double getAgencia() {
        return agencia;
    }

    public void setAgencia(double agencia) {
        this.agencia = agencia;
    }

    public double getNúmero() {
        return número;
    }

    public void setNúmero(double número) {
        this.número = número;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public abstract double getSaldoTotal();

    @Override
    public String toString() {
        return "Agência: " + agencia + " Número: " + número + " Saldo: " + saldo;
    }


}
