/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg1;

/**
 *
 * @author Aluno
 */
public class Exercício1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ContaCorrente cc1 = new ContaCorrente(01,01,100,500);
        ContaPoupanca cp1 = new ContaPoupanca(0.07,01,02,300);
        System.out.println(cc1);
        System.out.println(cp1);
        cc1.setLimite(5000);
        cp1.atualizarRendimento();
        System.out.println("\n"+cc1);
        System.out.println(cp1);
    }
    
}
