package exercício1;

/**
 *
 * @author  Igor Miranda Oliveira 
 */
public class Cliente{
private int codigo;
private String nome;
private boolean eClienteEspecial;
private double limiteCredito;
public Cliente(int codigo, String nome){
this.codigo = codigo;
this.nome = nome;
limiteCredito = 0;
eClienteEspecial = false;
}
public String getNome(){
return nome;
}
public boolean atualizaLimite(double x){
    if(eClienteEspecial){
        limiteCredito = x;
        return true; 
    }
    else
        return false;
        
}
public void atualizaSituacao(boolean y){
    if(y)
        eClienteEspecial = y;
    else
        limiteCredito = 0;
        
}
public String toString(){
    String sCli = "Nome:" + nome;
    sCli += "\n\tCodigo:" + codigo;
    sCli += "\n\tLimite:" + limiteCredito;
    if (eClienteEspecial)
        sCli += "\n\t O cliente é especial";
        return sCli;
    }
    public static void main(String[] args) {
    Cliente c1 = new Cliente(001,"Alice");
    Cliente c2 = new Cliente(002,"Bob");
    c2.atualizaSituacao(true);
    c2.atualizaLimite(400);
        System.out.println(c1);
        System.out.println(c2);   
    }

}
