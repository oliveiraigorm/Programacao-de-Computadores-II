
package exercício2;

public class A {
     
    private int x;
    private int y;
    public static int countA=0;

    public A(int x, int y){
    this.x=countA*2;
    this.y=countA*3;
    countA++;
}
    public void setX(int x){
        this.x=x;
    }
    public void setY(int y){
        this.y=y;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    public int getCountA(){
        return countA;
    }
    public String toString(){
    String sA = "x:" + x;
    sA += "\n\ty:" + y;
        return sA;
    }
    
}
