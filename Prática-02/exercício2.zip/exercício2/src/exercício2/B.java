
package exercício2;

import static exercício2.A.countA;

public class B {
    private static int a=0;
    private static int b=0;
      public void setA(int a){
        this.a=a;
    }
    public void setB(int b){
        this.b=b;
    }
    public int getA(){
        return a;
    }
    public int getB(){
        return b;
    }

    public static int getSoma(){
        return countA +a+b;
    }
    public String toString(){
    String sB = "a:" + a;
    sB += "\n\tb:" + b;
        return sB;
    }
    
}
