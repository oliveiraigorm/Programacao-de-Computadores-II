
package exercício2;

public class Teste {
          public static void main(String[] args) {
        A a1 = new A(3,7);
        A a2 = new A(7,1);
        A a3 = new A(12,6);
        System.out.println(a1);
        System.out.println(a3);
        System.out.println(a3);
        B b1 = new B();
        B b2 = new B();
        b1.setA(1);
        b1.setB(5);
        b2.setA(3);
        b2.setB(7);
        System.out.println(b1);
        System.out.println(b2);
        System.out.println(B.getSoma());
    }
}
