
package exercíco3;

public class TesteCilindro {
       public static void main(String[] args) {
        Cilindro c1 = new Cilindro(3,7);
        Cilindro c2 = new Cilindro(5,14);
        Cilindro c3 = new Cilindro(7,0.5);
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
    }
     
}
