
package exercíco3;
 
public class Cilindro {
    private double r;
    private double h;
    private static final double PI = 3.14;

    Cilindro(double r, double h) {
        this.r = r;
        this.h = h;
    }
public double aBase(double r, double h){
    return PI*r;
}    
public double aLat(double r, double h){
    return 2*PI*r*h;
}
public double aTot(double r, double h){
    return aLat(r,h)+2*aBase(r,h);
}
public String toString(){
    String Cl = "\n\tRaio:" + r;
    Cl += "\n\tAltura:" + h;
    Cl += "\n\tÁrea Base:" + aBase(r,h);
    Cl += "\n\tÁrea Lateral:" + aLat(r,h);
    Cl += "\n\tÁrea Total:" + aTot(r,h);
    return Cl;
    }

}
