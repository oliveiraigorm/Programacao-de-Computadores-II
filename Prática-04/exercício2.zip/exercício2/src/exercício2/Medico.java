/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício2;

/**
 *
 * @author Aluno
 */
public class Medico {
    String nome;
    String CRM;
    int idade;
    Especialidade es;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCRM() {
        return CRM;
    }

    public void setCRM(String CRM) {
        this.CRM = CRM;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Especialidade getEs() {
        return es;
    }

    public void setEs(Especialidade es) {
        this.es = es;
    }

    public Medico(String nome, String CRM, int idade, Especialidade es) {
        this.nome = nome;
        this.CRM = CRM;
        this.idade = idade;
        this.es = es;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + " Idade=" + idade + es;
    }
    
}
