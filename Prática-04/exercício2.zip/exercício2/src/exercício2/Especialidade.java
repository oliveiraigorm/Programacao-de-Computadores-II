
package exercício2;

public class Especialidade {
     
    private String es;
    private int cod;

    public String getEs() {
        return es;
    }

    public void setEs(String es) {
        this.es = es;
    }

    public Especialidade(String es, int cod) {
        this.es = es;
        this.cod = cod;
    }
    
    public String toString(){
    String sD = "\nEspecialidade: " + es;
    sD+= " (" +cod +")";
        return sD;
    }   
}