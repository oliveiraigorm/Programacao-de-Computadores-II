
package exercício2;


public class Teste {
    public static void main(String[] args) {
        Medico m1 = new Medico("Alice Fernandes", "001", 30, new Especialidade("Cardiolagista", 1293));
        System.out.println(m1);
    }
}