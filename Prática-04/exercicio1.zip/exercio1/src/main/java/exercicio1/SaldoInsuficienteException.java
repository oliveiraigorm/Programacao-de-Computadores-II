
package exercicio1;

public class SaldoInsuficienteException extends Exception{
public SaldoInsuficienteException(String msg){
 super(msg);
 }
}
