
package exercicio1;


public class Teste {
    public static void main(String[] args) {
        try{

ContaCorrente c1 = new ContaCorrente(10, 30);
c1.sacar(6000);
ContaCorrente c2 = new ContaCorrente(1000, 3000);
c1.sacar(-600);
        }
catch(SaldoInsuficienteException se){

System.out.println("Saldo insuficiente :(");

}

catch(ValorNegativoException be){

System.out.println("Erro: Tente novamente. " +be.getMessage());

}

finally{

System.out.println("Obrigado por usar nosso serviço!");

}
    }
}