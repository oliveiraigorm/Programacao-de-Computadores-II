package JogodaVelha;

public class TabuleiroJogodaVelha 
{
	public char [][] tabuleiro;
	private Jogador [] jogador;
	private int jogador_atual;
		
	public TabuleiroJogodaVelha (Jogador j1, Jogador j2)
	{
		jogador = new Jogador [2];
		jogador[0] = j1;
		jogador[1] = j2;	
		
		jogador_atual = 0;
		
		resetar();		
	}
	
	public void resetar()
	{
		tabuleiro = new char [3][3];
		
		//preencher cada posicao do tabuleiro com espaço em branco
		for (int i=0; i<tabuleiro.length; i++)
			for (int j=0; j<tabuleiro.length; j++)
				tabuleiro[i][j] = ' ';		
	}
	
	public void marcaJogada (Posicao p)
	{
//		for (int cont = 0; cont<jogador.length; cont++)
//				if (jogador[cont])
//						jogador_atual = cont;
		
		tabuleiro[p.getLinha()][p.getColuna()] = jogador[jogador_atual].getSimbolo();
	}
	
	public boolean estaMarcada(Posicao p)
	{
		if (tabuleiro[p.getLinha()][p.getColuna()] == ' ')//retorna falso se tiver com o valor inicializado
			return false;
		else
			return true;
	}
	
	public void alternaJogador()
	{
		if (jogador_atual == 0)
			jogador_atual = 1;
		else
			jogador_atual = 0;
	}
	
	//implementar
	public boolean checarLinhas()
	{
		int cont = 0;//variável que contará quantos simbolos do jogado atual há na linha atual
		//estrutura de repetição usada para percorrer as linhas do tabuleiro
		for (int i=0; i<tabuleiro.length; i++)
		{
			/*a variavel contadora inicializando em 0, possibilitará o incremento correto e também
			*pos		return false;
sibilitará que, quando terminar de percorrer uma linha, a contagem seja reiniciada para a 
			*proxima para linha
			*/
			cont=0;
			
			//estrutura para percorrer as colunas do tabuleiro
			for (int j=0; j<tabuleiro.length; j++)
			{
				/*variando as colunas, percorremos o fim de cada linha
				 * se o simbolo da posicao atual do tabuleiro for o simbolo do jogador atual,
				 * a variável contadora será incrementada.
				 */
				if (tabuleiro[i][j]==jogador[jogador_atual].getSimbolo())
					cont++;
				
				/* caso haja alguma linha em que o valor da variável 
				 * contadora chegue a 3, o método retornará verdadeiro e 
				 * terminará o laço for
				 */
				if (cont == 3)
					return true;				
			}
		}
		
		//retorna falso caso não haja uma linha completa com o simbolo do jogador atual	
		return false;
	}
	
	public boolean checarColunas()
	{
		int cont;//variável contadora do numero de simbolos do jogador atual
		
		//estrutura de repetição para percorrer cada coluna
		for (int j=0; j<tabuleiro.length; j++)
		{
			/*a variavel contadora inicializando em 0, possibilitará o incremento correto e também
			*possibilitará que, quando terminar de percorrer uma coluna, a contagem seja reiniciada para a 
			*proxima para coluna.
			*/
			cont = 0;
			
			//estrutura para percorrer cada linha
			for (int i=0; i<tabuleiro.length; i++)
			{
				/*com a ordem dos laços invertidas, fazemos a variação das linhas primeiro
				 * ao invés de variarmos as colunas.
				 */
				if (tabuleiro[i][j]==jogador[jogador_atual].getSimbolo())
					cont++;
				
				if (cont == 3)
					return true;		
			}
		}
		
		//retorna falso caso não haja uma linha completa com o simbolo do jogador atual	
		return false;
	}
	
	public boolean checarDiagonal()
	{
		//compara os valores da primeira diagonal
		if ( (tabuleiro[0][0]==jogador[jogador_atual].getSimbolo())&&(tabuleiro[1][1]==jogador[jogador_atual].getSimbolo())
				&& (tabuleiro[2][2]==jogador[jogador_atual].getSimbolo()) )
			return true;
		//compara os valores da segunda diagonal;
		else if ( (tabuleiro[0][2]==jogador[jogador_atual].getSimbolo())&&(tabuleiro[1][1]==jogador[jogador_atual].getSimbolo())
				&& (tabuleiro[2][0]==jogador[jogador_atual].getSimbolo()))
			return true;
		
		//caso não entre em nenhum caso de diagonal, retorna falso
		return false;		
	}
	
	public boolean deuVelha()
	{
		/*checa os metodos checarDiagona, checarColunas e checarLinhas.
		 * caso eles retornem falso, significa que nao houve vencedor, ou seja
		 * deu velha.
		 */
		if ( (checarDiagonal()==false) && (checarColunas()==false) && (checarLinhas()==false) )
			return true;
		
		else
			return false;
	}
	
	public boolean jogadorAtualHumano()
	{
		if (jogador[jogador_atual].getJogadorHumano()==true)
			return true;
		
		else
			return false;
	}
	//retorna o simbolo da posi��o passada como parametro
	public char simboloPosicao (Posicao p)
	{	
		return tabuleiro[p.getLinha()][p.getColuna()];	
	}
	
	//retorna o simbolo do jogador atual
	public char getSimboloJogadorAtual ()
	{
		return jogador[jogador_atual].getSimbolo();
	}
}
