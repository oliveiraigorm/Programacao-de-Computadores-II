package JogodaVelha;

import java.util.Random;

public class Jogador 
{
	private char simbolo;
	private boolean jogador_humano;
	
	public Jogador(char simbolo, boolean jogador_humano)
	{
		this.simbolo = simbolo;
		this.jogador_humano = jogador_humano;
	}
	
	public void marcarJogada (TabuleiroJogodaVelha jogo)
	{
		Random randlinha = new Random ();
		Random randcoluna = new Random();
		int linha, coluna;
		
		//la�o para colocar o s�mbolo do computador numa posi��o aleat�ria do tabuleiro
		do
		{
			linha = randlinha.nextInt(4); //gera numeros aleatorios entre 0 e 3 para linha
			coluna = randcoluna.nextInt(4); //gera numeros aleatorios entre 0 e 3 para coluna
			
		}while (jogo.tabuleiro[linha][coluna] != ' ');
		
		if (simbolo == 'X')
			jogo.tabuleiro[linha][coluna] = 'O';
		else
			jogo.tabuleiro[linha][coluna] = 'X';
	}	
	
	public char getSimbolo()
	{
		return simbolo;
	}
	
	public void setSimbolo (char simbolo)
	{
		this.simbolo = simbolo;
	}
	
	public boolean getJogadorHumano()
	{
		return jogador_humano;
	}
	
	public void setJogadorHumano (boolean jogador_humano)
	{
		this.jogador_humano = jogador_humano;
	}
}
