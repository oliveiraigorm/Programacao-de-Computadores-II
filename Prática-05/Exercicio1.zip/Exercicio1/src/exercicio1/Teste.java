package exercicio1;

import java.util.ArrayList;
import java.util.List;

public class Teste {
    public static void main(String[] args) {
        double[] vet={3,4,5,9,78,0};
        System.out.println(Estatistica.media(vet));
        System.out.println(Estatistica.maximo(vet));
        System.out.println(Estatistica.minimo(vet));
        List<Double> vet2 = new ArrayList<>();
        vet2.add(8.0); vet2.add(1.0); vet2.add(9.0); vet2.add(87.9);
        System.out.println("\n"+Estatistica.media(vet2));
        System.out.println(Estatistica.maximo(vet2));
        System.out.println(Estatistica.minimo(vet2));
    }
}
