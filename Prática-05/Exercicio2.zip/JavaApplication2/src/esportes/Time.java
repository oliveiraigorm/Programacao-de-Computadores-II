package esportes;
import exercicio1.Estatistica;
public class Time {
    Atleta [] team;
    public Time(Atleta [] atl) {
        if(atl==null||atl.length<=5 && atl.length>=11){
                 throw new IllegalArgumentException("Erro");
       }
        for (Atleta atl1 : atl) {
            if (atl1 == null) {
                throw new IllegalArgumentException("Erro");
            } 
        }
        this.team = atl;
    }
    public double[] getIMCAtletas(){
        double [] imc = new double[team.length];
        int i;
        for (i=0; i < team.length; i++) {
            imc[i] = team[i].getIMC();
        } 
        return imc;
    }
    public double getMediaIMC(){
        return Estatistica.media(getIMCAtletas());
    }
    public double getMaximoIMC(){
        return Estatistica.maximo(getIMCAtletas());   
    }
    public double getMinimoIMC(){
        return Estatistica.minimo(getIMCAtletas());
    }
    public Atleta getAtletaMaiorIMC(){
        int i;
        for (i=0; i < team.length; i++) {
            if(team[i].getIMC()==getMaximoIMC()){
                return team[i];
            }
        }
        return null;
    }

    public String toString() {
        String s1 = "";
        int i;
         for (i=0; i < team.length; i++) {
             s1 += "Dados do atleta:"+team[i]+"\n";
        } 
         s1 += "Dados do time:"+
                 "\nIMC medio:" + getMediaIMC()
                 +"\nIMC maximo:" + getMaximoIMC()
                 +"\nIMC minimo:" + getMinimoIMC();
        return s1;
    }
    
}
