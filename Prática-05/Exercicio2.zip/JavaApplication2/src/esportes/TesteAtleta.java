
package esportes;

public class TesteAtleta {

    public static void main(String[] args) {
    Atleta [] t1 = new Atleta[5];
    t1[0] = new Atleta("Alice", 1.7, 60.0);
    t1[1] = new Atleta("Bob", 1.6, 100.0);
    t1[2] = new Atleta("Jao", 1.9, 120.0);
    t1[3] = new Atleta("ana", 1.3, 50.0);
    t1[4] = new Atleta("fred", 1.5, 75.0);
    Time tfc = new Time (t1);
        System.out.println(tfc);
    }
    
}

