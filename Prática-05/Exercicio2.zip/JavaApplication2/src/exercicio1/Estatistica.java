package exercicio1;

/**
 *
 * @author Aluno
 */
import java.util.ArrayList;
import java.util.List;
public class Estatistica {

    public static double media(double[] valores){
        int i, tam;
        tam = valores.length;
        double media=0;
        for(i=0;i<tam;i++){
            media+=valores[i];
        }
        return media/tam;
    }
    public static double maximo(double[] valores){
        int i, c, tam;
        tam = valores.length;
        double maior=valores[0];
        for(i=0;i<tam;i++){
            if(valores[i]>maior){
                maior=valores[i];
            }
        }
        return maior;
    }
    public static double minimo(double[] valores){
        int i, c, tam;
        tam = valores.length;
        double menor=valores[0];
        for(i=0;i<tam;i++){
            if(valores[i]<menor){
                menor=valores[i];
            }
        }
        return menor;
    }
        public static double media(List<Double> valores){
        int i, tam;
        tam = valores.size();
        double media=0;
        for(i=0;i<tam;i++){
            media+=valores.get(i);
        }
        return media/tam;
    }
    public static double maximo(List<Double> valores){
        int i, c, tam;
        tam = valores.size();
        double maior=valores.get(0);
        for(i=0;i<tam;i++){
            if(valores.get(i)>maior){
                maior=valores.get(i);
            }
        }
        return maior;
    }
    public static double minimo(List<Double> valores){
        int i, c, tam;
        tam = valores.size();
        double menor=valores.get(0);
        for(i=0;i<tam;i++){
            if(valores.get(i)<menor){
                menor=valores.get(i);
            }
        }
        return menor;
    }
}
