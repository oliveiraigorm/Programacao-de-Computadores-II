/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg1;

/**
 *
 * @author Aluno
 */
public class ContaPoupanca extends Conta{
    private double rendimento;

    public ContaPoupanca(long num, double rendimento) {
        super(num);
        if(rendimento <=1 && rendimento >=0)
        this.rendimento = rendimento;
        else 
            System.out.println("Erro no rendimento");
    }

    public double getRendimento() {
        return rendimento;
    }

    public void setRendimento(double rendimento) {
                if(rendimento <=1 && rendimento >=0)
        this.rendimento = rendimento;
        else 
            System.out.println("Erro no rendimento");
    }
    
    public void atualizarRendimento(){
        this.saldo *= (1+this.rendimento);
    }

    @Override
    public String toString() {
        return super.toString()+"ContaPoupanca{" + "rendimento=" + rendimento + " saldo= " + String.format("%2.2f", this.getSaldo()) + "}";
    }
    
    
    
}
