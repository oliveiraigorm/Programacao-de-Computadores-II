/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg1;

public class MainBanco {

    public static void main(String[] args) {

        ContaPoupanca []ContasP = new ContaPoupanca[1000];
        int i;
        
        for(i=0; i<1000; i++){
            
            ContasP[i] = new ContaPoupanca(i, 0.1);
            ContasP[i].depositar((i+1)*100);
            ContasP[i].atualizarRendimento();
            System.out.println(ContasP[i]);
        }
        /*
        System.out.println(minhaConta);
        minhaConta.depositar(300);
        if (minhaConta.sacar(200)) {
            System.out.println("** após saque **");
            System.out.println(minhaConta);
        } 
        else {
            System.err.println("Não foi possível realizar a operação."
                    + "Saldo total disponível é de "
                    + minhaConta.getSaldoTotal());
        }*/
        
    }

}
