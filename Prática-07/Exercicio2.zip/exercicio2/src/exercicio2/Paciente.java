/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

import exercicio2.Pessoa;

/**
 *
 * @author Aluno
 */
public class Paciente extends Pessoa {

    private Convenio c1;

    public Paciente(Convenio c1, String cpf, String rg, String nome, String estadocivil, Cidade cidade, Estado estado, Telefone telefone) {
        super(cpf, rg, nome, estadocivil, cidade, estado, telefone);
        this.c1 = c1;
    }

    public Convenio getC1() {
        return c1;
    }

    public void setC1(Convenio c1) {
        this.c1 = c1;
    }

    @Override
    public String toString() {
        return super.toString() + " "+ c1 ;
    }

}
