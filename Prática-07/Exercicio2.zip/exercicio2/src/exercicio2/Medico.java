
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

/**
 *
 * @author Aluno
 */
public class Medico extends Pessoa{
    private String crm;
    private Especialidade e;

    public Medico(String crm, Especialidade e, String cpf, String rg, String nome,
            String estadocivil, Cidade cidade, Estado estado, Telefone telefone) {
        super(cpf, rg, nome, estadocivil, cidade, estado, telefone);
        this.crm = crm;
        this.e = e;
    }
	public String getCrm() {
		return crm;
	}
	public void setCrm(String crm) {
		this.crm = crm;
	}
	public Especialidade getE() {
		return e;
	}
	public void setE(Especialidade e) {
		this.e = e;
	}
	@Override
	public String toString() {
		return super.toString()+" CRM: " + crm + e;
	}
    
}