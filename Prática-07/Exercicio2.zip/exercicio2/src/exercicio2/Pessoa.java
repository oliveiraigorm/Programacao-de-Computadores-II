/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

/**
 *
 * @author Aluno
 */
public class Pessoa {

    private String cpf, rg, nome, estadocivil;
    private Cidade cidade;
    private Estado estado;
    private Telefone telefone;

    public Pessoa(String cpf, String rg, String nome, String estadocivil,
            Cidade cidade, Estado estado, Telefone telefone) {
        super();
        this.cpf = cpf;
        this.rg = rg;
        this.nome = nome;
        this.estadocivil = estadocivil;
        this.cidade = cidade;
        this.estado = estado;
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstadocivil() {
        return estadocivil;
    }

    public void setEstadocivil(String estadocivil) {
        this.estadocivil = estadocivil;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public Telefone getTelefone() {
        return telefone;
    }

    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return "CPF: " + cpf + " RG: " + rg +" "+  nome
                + " "+estadocivil +" "+ cidade +" "+ estado + " "+ telefone ;
    }

}
