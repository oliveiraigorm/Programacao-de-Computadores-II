/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio2;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Aluno
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Especialidade e1 = new Especialidade(1, "cardiologia");
        Especialidade e2 = new Especialidade(2, "neurologia");
        Convenio cn1 = new Convenio(01, "MEDmais");
        Cidade c1 = new Cidade("Belo Horizonte");
        Cidade c2 = new Cidade("Sao Paulo");
        Estado et1 = new Estado("Minas Gerais", "MG");
        Estado et2 = new Estado("Sao Paulo", "SP");
        Telefone t1 = new Telefone(31, 638729303);
        Telefone t2 = new Telefone(11, 840920109);
        
        Medico m1 = new Medico("123", e1, "123456", "2355", "Joao", "casado", c1, et1, t1);
        Medico m2 = new Medico("231", e2, "830201", "8492", "Maria", "viuva", c2, et2, t2);
        Pessoa p1 = new Paciente(cn1,"16281", "74239", "Bob", "solteiro", c1, et2, t2);
        Paciente pa1 = new Paciente(cn1,"84920", "84920", "Ana", "solteira", c2, et2, t2);
        List<Pessoa> lp = new ArrayList<>();
        lp.add(m1);
        lp.add(m2);
        lp.add(p1);
        lp.add(pa1);
        
        Iterator i = lp.iterator();
        while (i.hasNext()) {
            System.out.print(i.next() + "\n");
        }
    }

}
