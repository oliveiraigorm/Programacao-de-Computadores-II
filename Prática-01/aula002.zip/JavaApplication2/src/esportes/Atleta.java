package esportes;

public class Atleta {
    private String nome;    
    private double altura, peso;   
    
    private static final double IMC_MAX = 28;
    
   public Atleta(String nome, double altura, double peso) {
		this.nome = nome;
		this.altura = altura;
		this.peso = peso;
	}   
   public double getAltura(){
       return altura;
   }
   public double getPeso(){
       return peso;
   }
   public void setPeso(double peso){
       this.peso = peso;
   }
      public void setAltura(double altura){
       this.altura = altura;
   }
      public double getIMC(){
       return peso/Math.pow(altura,2);
   }
    public boolean estaAcimaDoPeso(){
          if(getIMC()> Atleta.IMC_MAX)
              return true;
          else
              return false;
      }
    public String toString(){
    String sAtl= "Nome:" + nome;
    sAtl = sAtl + "\n\t peso:" + peso;
    if (estaAcimaDoPeso())
        sAtl += "\n\t O atleta esta acima do peso";
        return sAtl;
    }

}