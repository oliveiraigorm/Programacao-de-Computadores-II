
package esportes;

public class TesteAtleta {

    public static void main(String[] args) {
        Atleta a1 = new Atleta("Alice", 1.7, 60.0);
        Atleta a2 = new Atleta("Bob", 1.5, 100.0);
        
        System.out.println(a1.getIMC());
        System.out.println("IMC do a2:" + a2.getIMC());
        
    }
    
}

