/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg1;

public class MainBanco {

    public static void main(String[] args) {
        
        GerenciaBanco gb = new GerenciaBanco(1, 1984);
        ContaCorrente cc1 = new ContaCorrente(01, 100);
        ContaCorrente cc2 = new ContaCorrente(02, 100);
        ContaCorrente cc3 = new ContaCorrente(03, 100);
        ContaPoupanca cp1 = new ContaPoupanca(04, 0.7);
        ContaPoupanca cp2 = new ContaPoupanca(05, 0.8);
        
        cc1.depositar(100);
        cc2.depositar(100);
        cc3.depositar(100);
        cp1.depositar(100);
        cp2.depositar(100);
        
        try{
        gb.adicionarConta(cc1);
        gb.adicionarConta(cc2);
        gb.adicionarConta(cc3);
        gb.adicionarConta(cp1);
        gb.adicionarConta(cp2);
        }
        catch(ContaJaExistente x){
            System.out.println("ERRO");
        }
        //saldo anterior 800 atual 500
        finally{
            System.out.println(gb);
            gb.ma.mudouMes();
            for(int i =0;i<12*30;i++){
            gb.mudouMes();
            }
            
            System.out.println(gb);
        }
        
    }

}
