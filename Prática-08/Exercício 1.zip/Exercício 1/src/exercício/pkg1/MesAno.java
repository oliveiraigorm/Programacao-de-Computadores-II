/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg1;

/**
 *
 * @author Aluno
 */
public class MesAno {
    private int mes, ano;

    public MesAno(int mes, int ano) {
        if(mes<=12 && mes>=1){
        this.mes = mes;
        this.ano = ano;
        }
        else
            System.out.println("Erro de mes");
    }

    public MesAno(int ano) {
        this(1, ano);
    }

    public int getMes() {
        return mes;
    }
    
    public String getNomeMes(){
         String []meses = {"janeiro", "fevereiro","março","abril","maio","junho",
            "julho","agosto","setembro","outubro","novembro","dezembro"};
        return meses[this.mes-1];
    }
    public int getAno() {
        return ano;
    }
    public void mudouMes(){
        if(this.mes==12){
            this.mes = 1;
            this.ano++;
        }
        else{
            this.mes++;
        }
        
    }

    @Override
    public String toString() {
        return "Mês: " + getNomeMes() + " Ano: " + ano;
    }
    
}
