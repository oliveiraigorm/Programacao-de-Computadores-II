package exercício.pkg1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Aluno
 */
public class GerenciaBanco {

    List<Conta> lc = new ArrayList<>();
    MesAno ma;

    public GerenciaBanco(int mes, int ano) {
        this.ma = new MesAno(mes, ano);
    }

    public GerenciaBanco(MesAno ma) {
        if (ma == null) {
            this.ma = new MesAno(1, 2000);
        } else {
            this.ma = ma;
        }
    }

    public void adicionarConta(Conta c) throws ContaJaExistente {
            for(Conta x : lc){
                if (x.equals(c)) 
            throw new ContaJaExistente("Erro");
            }
            this.lc.add(c);
    }

    public double getSaldoTotalContas() {
        double total = 0;
        for (Conta c : lc) {
            total += c.getSaldoTotal();
        }
        return total;
    }

    public int getTotalContasPoupancas() {
        int total = 0;
        for (Conta c : lc) {
            if (c instanceof ContaPoupanca) {
                total++;
            }
        }
        return total;
    }

    public List getContasCorrentes() {
        List<ContaCorrente> lista = new ArrayList<>();
        for (Conta c : lc) {
            if (c instanceof ContaCorrente) {
                lista.add((ContaCorrente) c);
            }
        }
        return lista;
    }

    public ContaPoupanca maiorRendimento() {
        double maiorrend = 0;
        ContaPoupanca cm = null;
        for (Conta c : lc) {
            if (c instanceof ContaPoupanca) {
                if (((ContaPoupanca) c).getRendimento() > maiorrend) {
                    cm = (ContaPoupanca) c;
                }
            }
        }
        return cm;
    }

    public void mudouMes() {
        ma.mudouMes();
        for(Conta c : lc) {
            if (c instanceof ContaPoupanca) {
                ContaPoupanca c1 = (ContaPoupanca) c;
                c1.atualizarRendimento();
            }
        }
    }

    @Override
    public String toString() {
        return ma.toString() + " Saldo Total: " + getSaldoTotalContas()
                + " Total de contas poupança:" + getTotalContasPoupancas()
                + " Conta poupança de maior rendimento: "
                + maiorRendimento().toString();
    }

}
