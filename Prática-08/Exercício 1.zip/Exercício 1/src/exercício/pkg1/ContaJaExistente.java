/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercício.pkg1;

/**
 *
 * @author Aluno
 */
class ContaJaExistente extends Exception {

    public ContaJaExistente(String message) {
        super(message);
    }
    
}
