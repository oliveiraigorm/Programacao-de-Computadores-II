/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teste;

import java.util.ArrayList;
import java.util.List;


public class GerenteLivros {
    private List<Livro> lstLivros = new ArrayList<>();
    private List<Editora> lstEditoras = new ArrayList<>();

    public GerenteLivros() {
        lstEditoras = criaEditoras();
        lstLivros = criaLivros(lstEditoras);
    }
    public static List<Editora> criaEditoras(){
        List<Editora> lstEditoras = new ArrayList<Editora>();
        lstEditoras.add(new Editora("Não Leia"));
        lstEditoras.add(new Editora("BCD"));
        return lstEditoras;
    }
    public static List<Livro> criaLivros(List<Editora> lstEd){
        List<Livro> lstLivro = new ArrayList<Livro>();
        lstLivro.add(new Livro("livro 1", lstEd.get(0)));
        lstLivro.add(new Livro("livro 2", lstEd.get(1)));
        return lstLivro;    
    }
    public void addLivro(Livro l){
        lstLivros.add(l);
    }
    public void addEditora(Editora e){
        lstEditoras.add(e);
    }
    public void removeLivro(int idx){
        lstLivros.remove(idx);
    }

    public List<Livro> getLstLivros() {
        return lstLivros;
    }
    public Livro getLivro(int idx) {
        return lstLivros.get(idx);
    }
    

    public void setLstLivros(List<Livro> lstLivros) {
        this.lstLivros = lstLivros;
    }

    public List<Editora> getLstEditoras() {
        return lstEditoras;
    }

    public void setLstEditoras(List<Editora> lstEditoras) {
        this.lstEditoras = lstEditoras;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
