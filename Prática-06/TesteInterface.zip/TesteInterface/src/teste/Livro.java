/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package teste;


public class Livro {
    private String titulo;
    private Editora ed;

    public Livro(String titulo, Editora ed) {
        this.titulo = titulo;
        this.ed = ed;
    }

    public Livro() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Editora getEd() {
        return ed;
    }

    public void setEd(Editora ed) {
        this.ed = ed;
    }

    @Override
    public String toString() {
        return this.titulo;
    }
    
}
