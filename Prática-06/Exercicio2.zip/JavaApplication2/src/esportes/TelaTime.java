package esportes;
import java.util.Set; 
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;


public class TelaTime {
    public static void imprimeQuantidadeDePessoaPorIdade(){
        Map<Integer, Integer> mapa = new HashMap<>();
        int i;
        for(i=0; i< Time.team.length ; i++){
            if(mapa.containsKey (Time.team[i].idade)){
                mapa.put(Time.team[i].idade, mapa.get(Time.team[i].idade) + 1);
            }
            else{
                mapa.put(Time.team[i].idade, 1);
            }
        }       
        Integer ch;
        Set<Integer> chaves = mapa.keySet();
        Iterator<Integer> c = chaves.iterator();
            while(c.hasNext()){
                ch = c.next();
                System.out.print("\nIdade: " + ch);
                System.out.print(" quantidade: " + mapa.get(ch));
            }
   
    }
}


