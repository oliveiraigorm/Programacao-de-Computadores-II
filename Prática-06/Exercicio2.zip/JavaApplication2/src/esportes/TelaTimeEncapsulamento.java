package esportes;
import java.util.Set; 
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;


public class TelaTimeEncapsulamento {
    public static void imprimeQuantidadeDePessoaPorIdade(){
        Map<Integer, Integer> mapa = new HashMap<>();
        int i;
        for(i=0; i< Time.team.length ; i++){
            if(mapa.containsKey (Time.team[i].getIdade())){
                mapa.put(Time.team[i].getIdade(), mapa.get(Time.team[i].getIdade()) + 1);
            }
            else{
                mapa.put(Time.team[i].getIdade(), 1);
            }
        }       
        Integer ch;
        Set<Integer> chaves = mapa.keySet();
        Iterator<Integer> c = chaves.iterator();
            while(c.hasNext()){
                ch = c.next();
                System.out.print("\nIdade: " + ch);
                System.out.print(" quantidade: " + mapa.get(ch));
            }
   
    }
}


